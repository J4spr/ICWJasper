from django.shortcuts import render
from django.views import generic
from .models import *
from django.forms import ModelForm
from .forms import *
from django.views.generic.edit import FormView

# Create your views here.
class ArticleListView(generic.ListView):
    
    # Listvuew heeft een attr model
    model =  Article
    
    # de naam van de database objecten in je html set
    template_name = 'blogsite/article.html'
    
    # wordt gebruikt door listview en geeft ALLE articles mee
    context_object_name = 'articles'
    
    queryset = Article.objects.all()

    # waar staat de html? (in je eigen files)
    template_name = 'blogsite/index.html'

    # paginate_by = 10

class ArticleDetailView(generic.DetailView):
    # detail view heeft enkel een model nodig en een private key
    model = Article


    template_name = 'blogsite/article.html'

class ArticleFormView(FormView):
    form_class = ArticleModelForm
    template_name = 'blogsite/form.html'
    success_url = '/blogsite'

    def form_valid(self, form):
        form.save()
        return super().form_valid(form)
    
